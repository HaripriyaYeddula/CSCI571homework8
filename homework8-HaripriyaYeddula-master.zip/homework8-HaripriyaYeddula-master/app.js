var express = require('express');
var http = require('http');
var https = require('https');
var url = require('url');
var server = express();
var port = process.env.PORT ||8081;


server.get('/',function(req,res){res.sendFile(__dirname + '/index.html');
});
server.use(express.static(__dirname));
server.get('/autocompleteziproute', function(request,response){
   response.setHeader("Access-Control-Allow-Origin","*");
   response.setHeader("Content-Type","Application/json");
   var params = url.parse(request.url, true).query;
   var autocomplete_url = "http://api.geonames.org/postalCodeSearchJSON?postalcode_startsWith="+ params.startswith +"&username=haripriyayeddula&country=US&maxRows=5";
   http.get(autocomplete_url,function(request2, response2){
     var res_text = "" ;
     request2.on('data',function(data){
       res_text+=data;
     });

     request2.on('end',function(){
       return response.send(JSON.parse(res_text));
     });

   });
});
server.get("/shippingroute", function(request, response){
  response.setHeader("Access-Control-Allow-Origin","*");
  response.setHeader("Content-Type","Application/json");
  var i = 0;
  var params = url.parse(request.url, true).query;
  var productsearch_url = "http://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=Haripriy-ProductS-PRD-116e557a4-83799a68&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&paginationInput.entriesPerPage=50&keywords="+ params.keyword;
  console.log(productsearch_url);
  http.get(productsearch_url, function(request2, response2){
    var search_res = "";
    request2.on('data', function(data){
      search_res += data;
    });
    request2.on('end', function(data){
      return response.send(search_res);
    });
  }); // end of http get
}); //end of product search

server.get("/productSearchroute", function(request, response){
  response.setHeader("Access-Control-Allow-Origin","*");
  response.setHeader("Content-Type","Application/json");
  var i = 0;
  var params = url.parse(request.url, true).query;
  var productsearch_url = "http://svcs.ebay.com/services/search/FindingService/v1?OPERATION-NAME=findItemsAdvanced&SERVICE-VERSION=1.0.0&SECURITY-APPNAME=Haripriy-ProductS-PRD-116e557a4-83799a68&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&paginationInput.entriesPerPage=50&keywords="+ params.keyword;

  if(params.categoryId != 0){
    productsearch_url = productsearch_url + "&categoryId=" + params.categoryId;
  }
  productsearch_url = productsearch_url + "&buyerPostalCode="+params.zipcode;
  productsearch_url = productsearch_url + "&itemFilter("+i+").name=HideDuplicateItems&itemFilter("+i+").value=true"; i++;
  productsearch_url = productsearch_url + "&itemFilter("+i+").name=MaxDistance&itemFilter("+i+").value="+params.distance; i++;

  switch (params.shipping) {
    case "localpickup":
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=false";
      i++;
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=LocalPickupOnly&itemFilter("+i+").value=true";
      i++;
      break;
    case "freeship":
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=true";
      i++;
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=LocalPickupOnly&itemFilter("+i+").value=false";
      i++;
      break;
    case "localfree":
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=FreeShippingOnly&itemFilter("+i+").value=true";
      i++;
      productsearch_url = productsearch_url + "&itemFilter("+i+").name=LocalPickupOnly&itemFilter("+i+").value=true";
      i++;
      break;
  }
  if(params.condition != "All"){
    productsearch_url = productsearch_url + "&itemFilter("+i+").name=Condition";
    switch(params.condition){
      case "NewUsed":
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(0)=New";
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(1)=Used";
        break;
      case "UsedUnspecified":
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(0)=Used";
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(1)=Unspecified";
        break;
      case "UnspecifiedNew":
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(0)=New";
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(1)=Unspecified";
        break;
      default:
        productsearch_url = productsearch_url + "&itemFilter("+i+").value(0)="+params.condition;
        break;
    }
  }
  productsearch_url = productsearch_url + "&outputSelector(0)=SellerInfo&outputSelector(1)=StoreInfo%20";
  http.get(productsearch_url, function(request2, response2){
    var search_res = "";
    request2.on('data', function(data){
      search_res += data;
    });
    request2.on('end', function(data){
      return response.send(search_res);
    });
  }); // end of http get
}); //end of product search
server.get('/itemDetailSearchroute', function(request,response){
   response.setHeader("Access-Control-Allow-Origin","*");
   response.setHeader("Content-Type","Application/json");
   var params = url.parse(request.url, true).query;
   var itemdetailsearch_url =  "http://open.api.ebay.com/shopping?callname=GetSingleItem&responseencoding=JSON&appid=Haripriy-ProductS-PRD-116e557a4-83799a68&siteid=0&version=967&ItemID="+params.itemId+"&IncludeSelector=Description,Details,ItemSpecifics"
      http.get(itemdetailsearch_url,function(request2, response2){
     var res_text = "" ;
     request2.on('data',function(data){
       res_text+=data;
     });

     request2.on('end',function(){
       return response.send(JSON.parse(res_text));
     });

   });
});
server.listen(port, () => {
  console.log('Example app listening on port 8081!')
});
server.get('/googlePhotosSearchroute', function(request,response){
   response.setHeader("Access-Control-Allow-Origin","*");
   response.setHeader("Content-Type","Application/json");
   var params = url.parse(request.url, true).query;
   var gse_url = "https://www.googleapis.com/customsearch/v1?q="+ params.name +"&cx=005291819790118960161:8vgp8zekdns&imgSize=huge&imgType=news&num=8&searchType=image&key=AIzaSyB-WCrQQhcKmzbyRa6WVPdJxgo2k976Xxg";
   https.get(gse_url,function(request2, response2){
     var res_text = "" ;
     request2.on('data',function(data){
       res_text+=data;
     });

     request2.on('end',function(){
       return response.send(JSON.parse(res_text));
     });

   });
});
server.get('/similarItemsSearchroute', function(request, response){
  response.setHeader("Access-Control-Allow-Origin","*");
  response.setHeader("Content-Type","Application/json");
  var params = url.parse(request.url, true).query;
  var similar_url = "http://svcs.ebay.com/MerchandisingService?OPERATION-NAME=getSimilarItems&SERVICE-NAME=MerchandisingService&SERVICE-VERSION=1.1.0&CONSUMER-ID=Haripriy-ProductS-PRD-116e557a4-83799a68&siteid=0&version=967&RESPONSE-DATA-FORMAT=JSON&REST-PAYLOAD&itemId=" + params.itemId + "&maxResults=20";
  http.get(similar_url,function(request2, response2){
    var res_text = "" ;
    request2.on('data',function(data){
      res_text+=data;
    });

    request2.on('end',function(){
      return response.send(JSON.parse(res_text));
    });

  });
});
