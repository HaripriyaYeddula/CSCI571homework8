var app = angular.module('myApp', ['ngAnimate','ngMaterial', 'ngMessages','angular-svg-round-progressbar']);


app.controller('myCtrl', function($scope, $http, $location)
{
  $scope.fromres = false;
  $scope.newsearch = true;
  $scope.wlviewbtn = false;
  $scope.zipvalid = true;
  $scope.noitems = false;
  $scope.customzipcode = "";
  $scope.showProductError = false;
  $scope.showShippingError = false;
  $scope.showPhotosError = false;
  $scope.showSellerError = false;
  $scope.showSimilarError = false;
  $scope.errortabmessage = "";
  $scope.sortbyfilter = "";
  $scope.sortby = false;
  $scope.limit = 5;
  $scope.similarItemsLength ="";
  $scope.similarItems = {};
  $scope.similarItemsArray = [];
  $scope.sellerInfo = {};
  $scope.photosToDisplay = {};
  $scope.shippingInfo = {};
  $scope.GSEphotoname ="";
  $scope.forphotos = [];
  $scope.parseditemdetails = {};
  $scope.changedparseditemdetails = {};
  $scope.lastwishlistitemdetail = {};
  $scope.lastviewitemfromresults = {};
  //views stuff
  $scope.selectedView ="";
  $scope.prevview="resultsTableView.html"; //doesnot change unless the user moves to wishlist view
  $scope.views = {
    resultstableview : "resultsTableView.html",
    itemdetailsview : "itemDetailsView.html",
    progressanderrorsview : "progressAndErrorView.html",
    productstabview: "productsTabView.html",
    photostabview: "photosTabView.html",
    shippingtabview : "shippingTabView.html",
    sellertabview : "sellerTabView.html",
    similarpdtstabview : "similarpdtsTabView.html",
    wishlisttabview : "WishlistView.html",
    taberrorview : "errorForTabs.html"
  }
  $scope.form = {
    keyword : "",
    category : "All Categories",
    condition_new :"" ,
    condition_used : "" ,
    condition_unspecified : "",
    localpickup : "" ,
    freeship : "" ,
  //  distance : "10",
    from : true,
    zipcode : "",
    foundzipcode : false,
    searchResults : "",
    displayNoRecords : false,
    resultTableData : "",
    tempSearch : ""
  }
  $scope.resultTableData = {
    items : []
  };
  $scope.showToolTip = false;
  $scope.totalItems = 0;
  $scope.thisPage = 0;
  $scope.perPageResults = 10;
  $scope.pagedItems =[];
  $scope.errormessage = "";
  $scope.showDetailsbtn = false;
  $scope.showDetailsbtnwl = false;
  $scope.showProgressBar = false;
  $scope.showWishlistTab = false;
  $scope.showError = false;
  $scope.showMoreBtn = true;
  $scope.apizipcodesuggestions = [];
  $scope.selectedIndex = -1;
  $scope.itemdetailsResults = {};
  $scope.clearform = function(){
    $scope.newsearch = true;
    $scope.form = {
      keyword : "",
      category : "All Categories",
      condition_new :"" ,
      condition_used : "" ,
      condition_unspecified : "",
      localpickup : "" ,
      freeship : "" ,
  //    distance : "10",
      from : true,
      zipcode : "",
      foundzipcode : false,
      searchResults : "",
      displayNoRecords : false,
      resultTableData : "",
      tempSearch : ""
    }
    $scope.customzipcode = "";
  }
  $scope.clear = function() {
    $scope.clearauto();
    $scope.clearform();
    $scope.newsearch = true;
    $scope.zipvalid = true;
    $scope.noitems = false;
    $scope.showProductError = false;
    $scope.showShippingError = false;
    $scope.showPhotosError = false;
    $scope.showSellerError = false;
    $scope.showSimilarError = false;
    $scope.errortabmessage = "";
    $scope.sortbyfilter = "";
    $scope.sortby = false;
    $scope.limit = 5;
    $scope.similarItemsLength ="";
    $scope.similarItems = {};
    $scope.similarItemsArray = [];
    $scope.sellerInfo = {};
    $scope.photosToDisplay = {};
    $scope.shippingInfo = {};
    $scope.GSEphotoname ="";
    $scope.forphotos = [];
    $scope.parseditemdetails = {};
    //views stuff
    $scope.selectedView ="";
    $scope.prevview="resultsTableView.html"; //doesnot change unless the user moves to wishlist view
    $scope.views = {
      resultstableview : "resultsTableView.html",
      itemdetailsview : "itemDetailsView.html",
      progressanderrorsview : "progressAndErrorView.html",
      productstabview: "productsTabView.html",
      photostabview: "photosTabView.html",
      shippingtabview : "shippingTabView.html",
      sellertabview : "sellerTabView.html",
      similarpdtstabview : "similarpdtsTabView.html",
      wishlisttabview : "WishlistView.html",
      taberrorview : "errorForTabs.html"
    }
    $scope.resultTableData = {
      items : []
    };
    $scope.showToolTip = false;
    $scope.totalItems = 0;
    $scope.thisPage = 0;
    $scope.perPageResults = 10;
    $scope.pagedItems =[];
    $scope.errormessage = "";
    $scope.showDetailsbtn = false;
    $scope.showDetailsbtnwl = false;
    $scope.showProgressBar = false;
    $scope.showWishlistTab = false;
    $scope.showError = false;
    $scope.showMoreBtn = true;
    $scope.apizipcodesuggestions = [];
    $scope.selectedIndex = -1;
    $scope.itemdetailsResults = {};
  }
  $scope.searchAgain = function(){
    $scope.resultTableData = {
      items : []
    };
    $scope.newsearch = true;
    $scope.totalItems = 0;
    $scope.thisPage = 0;
    $scope.perPageResults = 10;
    moveToResultsTab();
  }
  $scope.getzipcode = function() {
    $http.get("http://ip-api.com/json").then(function(response) {
            $scope.zipcode = response.data.zip;
            $scope.foundzipcode = true;
    });
  };
  $scope.noimages= false;
  $scope.selectedTab = "productsTabView.html";
  $scope.assignPhotoURLS = function(urls){
    $scope.forphotos = [];
    $scope.forphotoslength = urls.length;
      if(  $scope.forphotoslength == 0) $scope.noimages = true;
      else $scope.noimages = false;
      for (var i = 0; i < urls.length; i++) {
          $scope.forphotos.push(urls[i]);
      }
  };
  $scope.autocompletezip = function(enteredText) {
    $scope.apizipcodesuggestions = [];
    var params = {};
    params.startswith = enteredText;
    return $http.get("http://haripriya-yeddula.us-east-2.elasticbeanstalk.com/autocompleteziproute?startswith="+params.startswith).then(function(response){
    //  return $http.get("/autocompleteziproute?startswith="+params.startswith).then(function(response){
        if ( response!=undefined && response.data!=undefined) {
          var zipdata = response.data;
           $scope.apizipcodesuggestions = [];
          for (var i = 0; i < 5; i++) {
            if(zipdata["postalCodes"][i]!= undefined){
              $scope.apizipcodesuggestions.push(zipdata["postalCodes"][i]["postalCode"]);
            }
          }
          return $scope.apizipcodesuggestions;
      }
      else {
        $scope.apizipcodesuggestions = [];
        $scope.noitems=true;
        return   $scope.apizipcodesuggestions;
      }
  }); //end of http
}; //end of autocompletezip()
  $scope.clearauto = function() {
      $scope.selectedItem = null;
      $scope.enteredText = "";
  }
  $scope.selectedItemChange = function(item) {
      $scope.customzipcode = item;
      var exp = RegExp('^[0-9]{5}$');
      $scope.zipvalid = exp.test(item);
  }
  $scope.enteredTextChange = function(item) {
      $scope.customzipcode = item;
      var exp = RegExp('^[0-9]{5}$');
      $scope.zipvalid = exp.test(item);
  }
  $scope.onSubmit=function(){
      $scope.searchAgain();
      $scope.showProgressBar = true;
      $scope.selectedView = $scope.views.progressanderrorsview;
      var params = {};
      $scope.newsearch = false;
      params.keyword = $scope.form.keyword;
      switch ($scope.form.category) {
        case 'Art':
          params.categoryId = "550";
          break;
        case 'Baby':
          params.categoryId = "2984";
          break;
        case 'Books':
          params.categoryId = "267";
          break;
        case 'Clothing, Shoes N Accessories':
          params.categoryId = "11450";
          break;
        case 'Computers/Tablets N Networking':
          params.categoryId = "58058";
          break;
        case 'Health N Beauty':
          params.categoryId = "26395";
          break;
        case 'Music':
          params.categoryId = "11233";
          break;
        case 'Video Games N Consoles':
          params.categoryId = "1249";
          break;
        default:
          params.categoryId = "0";
          break;
      }

      if($scope.form.condition_new == false && $scope.form.condition_used == false && $scope.form.condition_unspecified == false)
        params.condition = "All";
      else if ($scope.form.condition_new == true && $scope.form.condition_used == false && $scope.form.condition_unspecified == false)
        params.condition = "New";
      else if ($scope.form.condition_new == false && $scope.form.condition_used == true && $scope.form.condition_unspecified == false)
          params.condition = "Used";
      else if ($scope.form.condition_new == false && $scope.form.condition_used == false && $scope.form.condition_unspecified == true)
          params.condition = "Unspecified";
      else if ($scope.form.condition_new == true && $scope.form.condition_used == true && $scope.form.condition_unspecified == false)
          params.condition = "NewUsed";
      else if ($scope.form.condition_new == false && $scope.form.condition_used == true && $scope.form.condition_unspecified == true)
          params.condition = "UsedUnspecified";
      else
          params.condition = "UnspecifiedNew";

      if($scope.form.localpickup == true && $scope.form.freeship == false)
          params.shipping = "localpickup";
      else if($scope.form.localpickup == false && $scope.form.freeship == true)
          params.shipping = "freeship";
      else if($scope.form.localpickup == true && $scope.form.freeship == true)
          params.shipping = "localfree";
      else
          params.shipping = "none";

      if( $scope.form.distance != undefined)
      params.distance = $scope.form.distance;
      else
      params.distance = 10;

      if($scope.form.from == false)
        params.zipcode = $scope.customzipcode;
      else
        params.zipcode = $scope.zipcode;

      $http.get("http://haripriya-yeddula.us-east-2.elasticbeanstalk.com/productSearchroute?keyword="+params.keyword+"&condition="+params.condition+"&categoryId="+params.categoryId+"&shipping="+params.shipping+"&distance="+params.distance+"&zipcode="+params.zipcode)
    //  $http.get("/productSearchroute?keyword="+params.keyword+"&condition="+params.condition+"&categoryId="+params.categoryId+"&shipping="+params.shipping+"&distance="+params.distance+"&zipcode="+params.zipcode)
      .then(function(response){
        $scope.searchResults = response.data;
        if( $scope.searchResults["findItemsAdvancedResponse"] == undefined || $scope.searchResults["findItemsAdvancedResponse"]["0"]["searchResult"] == undefined || $scope.searchResults["findItemsAdvancedResponse"]["0"]["searchResult"]["0"] == undefined || $scope.searchResults["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"] == undefined )
        { //debug this
          //$scope.selectedView = $scope.selectView("progressAndErrorView.html");
          $scope.selectedView = $scope.views.progressanderrorsview;
          $scope.showError = true;
          $scope.showProgressBar = false;
          $scope.errormessage = "No Records.";
        }
        else{
          $scope.tempSearch = $scope.searchResults["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["item"] ;
          var image, name, price, shipping, zip, seller, wishlist, showToolTip, fullname, itemId;
          var length = $scope.searchResults["findItemsAdvancedResponse"]["0"]["searchResult"]["0"]["@count"];
          $scope.totalItems = length;           $scope.showProgressBar = false;
          if ($scope.totalItems == 0)           $scope.selectedView = $scope.views.progressanderrorsview;
          else                                  $scope.selectedView = $scope.views.resultstableview;
          $scope.paginationPages = Math.ceil(length/10);
          for (var i = 0; i < length; i++) {
            var index = i+1;
            if ($scope.tempSearch[i]["galleryURL"] == undefined || $scope.tempSearch[i]["galleryURL"]["0"] == undefined)
                image = "N/A";
            else
                image = $scope.tempSearch[i]["galleryURL"]["0"];
            if ($scope.tempSearch[i]["title"] == undefined)
                name = "N/A";
            else
              name = $scope.tempSearch[i]["title"]["0"];
            fullname = name;
            if (name.length>35){
                showToolTip = true;
                fullname = name;
                if (name[36]==" ")
                  name = name.substr(0,34);
                else{
                  var tempname = name.substr(0,34);
                  var cuthere = tempname.lastIndexOf(" ");
                  name = name.substr(0, cuthere) + "...";
                }
            }
            if($scope.tempSearch[i]["sellingStatus"] == undefined || $scope.tempSearch[i]["sellingStatus"]["0"]["currentPrice"] == undefined || $scope.tempSearch[i]["sellingStatus"]["0"]["currentPrice"]["0"]["__value__"] == undefined)
              price = "N/A";
            else
              price = "$"+ $scope.tempSearch[i]["sellingStatus"]["0"]["currentPrice"]["0"]["__value__"];
            if($scope.tempSearch[i]["shippingInfo"] == undefined || $scope.tempSearch[i]["shippingInfo"]["0"]["shippingServiceCost"] == undefined || $scope.tempSearch[i]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"] == undefined)
              shipping = "N/A";
            else{
              if($scope.tempSearch[i]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"] == "0.0")
                shipping = "Free Shipping";
              else
                shipping = $scope.tempSearch[i]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"];
            }
            if($scope.tempSearch[i]["postalCode"] == undefined || $scope.tempSearch[i]["postalCode"]["0"] == undefined)
                zip = "N/A";
            else
                zip = $scope.tempSearch[i]["postalCode"]["0"];
            if($scope.tempSearch[i]["sellerInfo"] == undefined || $scope.tempSearch[i]["sellerInfo"]["0"] == undefined || $scope.tempSearch[i]["sellerInfo"]["0"]["sellerUserName"] == undefined || $scope.tempSearch[i]["sellerInfo"]["0"]["sellerUserName"]["0"] == undefined)
                seller = "N/A";
            else
                seller = $scope.tempSearch[i]["sellerInfo"]["0"]["sellerUserName"]["0"];

            if($scope.tempSearch[i]["itemId"] == undefined || $scope.tempSearch[i]["itemId"]["0"] == undefined){
              itemId = "No details available";
            }else{
              itemId = $scope.tempSearch[i]["itemId"]["0"];
            }

            $scope.resultTableData.items.push({
                  "index" : index,
                  "itemId" :itemId,
                  "image" : image,
                  "name"  : name,
                  "price" : price,
                  "shipping": shipping,
                  "zip": zip,
                  "seller": seller,
                  "showToolTip": showToolTip,
                  "fullname" : fullname,
                  "in_cart" : false,
                  "highlight": false,
            });
          }
          $scope.pageGrouping();
        }
      });
  }; //end of onSubmit()
  $scope.ifinrange = function(min, max, toinc){
   var page=[]; toinc=toinc||1;
      for (var j= min; j<= max; j+= toinc) {page.push(j);}
   return page;
  };
  $scope.gotoPrevious = function(){
    if ($scope.thisPage > 0)
    {$scope.thisPage--;}
  };

  $scope.getProductDetails = function(){
    $scope.resetErrorFlags();
    if (  $scope.itemdetailsResults  == undefined){
      $scope.showProgressBar = false;
      $scope.showProductError = true;
      $scope.errortabmessage = "No Records.";
      $scope.selectView($scope.views.itemdetailsview);
      $scope.selectTab("errorForTabs.html");
    } else
    $scope.selectTab($scope.views.productstabview);
  }

  $scope.gotoNext = function() {
    if ($scope.thisPage < $scope.pagedItems.length - 1)
    {   $scope.thisPage++;   }
  };

  $scope.resetHighlights = function(){
    for (var i = 0; i < $scope.totalItems; i++) {
      $scope.resultTableData.items[i]["highlight"] = false;    }
  }
  $scope.itemDetailSearch = function(itemId, customIndex){
    if($scope.prevview == "resultsTableView.html")
    {
          $scope.resetHighlights();
          $scope.resultTableData.items[customIndex-1]["highlight"] = true;
    }
    if( $scope.wishtlistItems != undefined && $scope.wishtlistItems != [])
    {
      $scope.resetHighlightForWishlist();
      for(var variable in $scope.wishtlistItems){
        if($scope.wishtlistItems[variable]["index"] == customIndex)
          $scope.wishtlistItems[variable]["highlight"]=true;}
    }
    $scope.showProgressBar = true; $scope.showError = false;
    $scope.selectedView = $scope.views.progressanderrorsview;
    $http.get("http://haripriya-yeddula.us-east-2.elasticbeanstalk.com/itemDetailSearchroute?itemId="+itemId)
  //  $http.get("/itemDetailSearchroute?itemId="+itemId)
    .then(function(response){
      $scope.itemdetailsResults = response.data.Item;
      if (  $scope.itemdetailsResults  == undefined){
        $scope.showProgressBar = false;
        $scope.showProductError = true;
        $scope.errortabmessage = "No Records.";
        $scope.selectView($scope.views.itemdetailsview);
        $scope.selectTab("errorForTabs.html");
      }else{
        $scope.itemdetailsResults = response.data.Item;
        var pdtimgs=[],subtitle,price,loc,retpol,itemspecs = [];
        $scope.changedparseditemdetails["customIndex"] = customIndex;
        $scope.changedparseditemdetails["Title"] = $scope.itemdetailsResults.Title;
        if($scope.itemdetailsResults["PictureURL"]!=undefined)
            $scope.changedparseditemdetails["Product Images"] = $scope.itemdetailsResults["PictureURL"];
        if($scope.itemdetailsResults["Subtitle"]!=undefined)
            $scope.changedparseditemdetails["Subtitile"] = $scope.itemdetailsResults["Subtitle"];
        if($scope.itemdetailsResults["CurrentPrice"] !=undefined && $scope.itemdetailsResults["CurrentPrice"]["Value"] !=undefined)
            $scope.changedparseditemdetails["Price"] = $scope.itemdetailsResults["CurrentPrice"]["Value"];
        if($scope.itemdetailsResults["ReturnPolicy"] != undefined && $scope.itemdetailsResults["ReturnPolicy"]["ReturnsAccepted"]!= undefined )
        {
            var tempshipinfo =  $scope.itemdetailsResults["ReturnPolicy"]["ReturnsAccepted"]  ;
            if($scope.itemdetailsResults["ReturnPolicy"]["ReturnsAccepted"]["ReturnsWithin"] != undefined)
              tempshipinfo = tempshipinfo + " within " + $scope.itemdetailsResults["ReturnPolicy"]["ReturnsAccepted"]["ReturnsWithin"];
            $scope.changedparseditemdetails["Return Policy"] = tempshipinfo;
        }
        if($scope.itemdetailsResults["ItemSpecifics"]!=undefined && $scope.itemdetailsResults["ItemSpecifics"]["NameValueList"]!=undefined)
        {
            itemspecs = $scope.itemdetailsResults["ItemSpecifics"]["NameValueList"];
            for (var index in itemspecs)
              $scope.changedparseditemdetails[itemspecs[index]["Name"]] = itemspecs[index]["Value"]["0"];
        }
        if (customIndex != 1)
          var tempidx = (customIndex-1)%10;
        if (customIndex == 1)
          var tempidx = 1;
        if (tempidx == 0) tempidx = 1;
        if($scope.pagedItems[$scope.thisPage]!=undefined)
        {
          if($scope.pagedItems[$scope.thisPage][tempidx-1]["in_cart"] == false)
            $scope.changedparseditemdetails["in_cart"] = false;
          if($scope.pagedItems[$scope.thisPage][tempidx-1]["in_cart"] == true)
            $scope.changedparseditemdetails["in_cart"] = true;
        }
        $scope.showProgressBar = false;
         var temp = JSON.parse(JSON.stringify($scope.changedparseditemdetails));
        if($scope.prevview == "resultsTableView.html" && ($scope.pagedItems != [] || $scope.pagedItems != undefined || $scope.pagedItems.length != 0))
        {
          $scope.lastviewitemfromresults = angular.copy($scope.changedparseditemdetails);//$scope.parseditemdetails = $scope.lastviewitemfromresults;
        }
        else if($scope.prevview == "WishlistView.html" && ($scope.pagedItems == [] || $scope.pagedItems == undefined || $scope.pagedItems.length == 0) )
        {
          $scope.lastwishlistitemdetail =angular.copy($scope.changedparseditemdetails);//$scope.parseditemdetails = $scope.lastwishlistitemdetail ;
        }
        else if($scope.prevview == "WishlistView.html" && ($scope.pagedItems != [] || $scope.pagedItems != undefined || $scope.pagedItems.length != 0) )
        {
          $scope.lastwishlistitemdetail = angular.copy($scope.changedparseditemdetails); // $scope.parseditemdetails = $scope.lastwishlistitemdetail;
        }
        if($scope.wlviewbtn)
        {
            $scope.showDetailsbtnwl = true; $scope.showDetailsbtn =false;
        } else {
          $scope.showDetailsbtn =true; $scope.showDetailsbtnwl = false;
        }
        $scope.parseditemdetails = angular.copy($scope.changedparseditemdetails);
        $scope.selectView($scope.views.itemdetailsview);
        $scope.selectTab("productsTabView.html");
      }
    });
  };
  $scope.fetchDetailsOnViews = function(){
    if($scope.wlviewbtn){
      $scope.parseditemdetails = JSON.parse(JSON.stringify($scope.lastwishlistitemdetail));
      console.log($scope.parseditemdetails);
    }
    else
      $scope.parseditemdetails = JSON.parse(JSON.stringify($scope.lastviewitemfromresults)) ;
    $scope.selectView($scope.views.itemdetailsview);
    $scope.selectTab("productsTabView.html");
  }
  $scope.selectView = function(selectedView){
    if(selectedView=="itemDetailsView.html")
    {
      $scope.selectedView = "itemDetailsView.html";
    if ($scope.showDetailsbtn || $scope.showDetailsbtnwl)
      $scope.selectTab("productsTabView.html");
    }
    if(selectedView=="resultsTableView.html"){
      if ($scope.totalItems == 0) {
        $scope.wlviewbtn = false;
        $scope.showError = true; $scope.showDetailsbtn = false;
        $scope.errormessage = "No Records";
        $scope.selectedView = "progressAndErrorView.html"; $scope.prevview="progressAndErrorView.html";
      }else{
        $scope.showError = false;
        $scope.selectedView = "resultsTableView.html";  $scope.prevview="resultsTableView.html";  $scope.wlviewbtn = false;
        $scope.selectedTab = "";
        if((!$scope.isEmpty($scope.lastviewitemfromresults)) || (!$scope.isEmpty($scope.resultTableData.items)))
          $scope.showDetailsbtn = true;
      }
    }
    if(selectedView=="WishlistView.html"){
      $scope.selectedView = "WishlistView.html"; $scope.prevview="WishlistView.html"; $scope.wlviewbtn = true;
      if(!($scope.isEmpty($scope.lastwishlistitemdetail)))
         $scope.showDetailsbtnwl = true;
    }
    if(selectedView == "progressAndErrorView.html"){
       $scope.selectedView = "progressAndErrorView.html";
    }
  }; //end of selectview

  $scope.isEmpty = function(tempcheck){return Object.keys(tempcheck).length === 0;};

  $scope.selectTab = function(selectedTab){
    if(selectedTab=="errorForTabs.html"){
      $scope.selectedTab = "errorForTabs.html";
    }
    if(selectedTab=="productsTabView.html"){
      $scope.selectedTab = "productsTabView.html";
    }
    if(selectedTab=="photosTabView.html"){
      $scope.selectedTab = "photosTabView.html";
    }
    if(selectedTab=="shippingTabView.html"){
      $scope.selectedTab = "shippingTabView.html";
    }
    if(selectedTab=="sellerTabView.html"){
      $scope.selectedTab = "sellerTabView.html";
    }
    if(selectedTab=="similarpdtsTabView.html"){
      $scope.selectedTab = "similarpdtsTabView.html";
    }
  };//End of selectedTab
  $scope.getPhotosGSE = function(photoname){
    $scope.resetErrorFlags();
    $http.get("http://haripriya-yeddula.us-east-2.elasticbeanstalk.com/googlePhotosSearchroute?name="+photoname).then(function(response){
  //  $http.get("/googlePhotosSearchroute?name="+photoname).then(function(response){
        if((response.data != undefined && response.data.items!= undefined)){
              for(var i=0; i< response.data.items.length ; i++){
                $scope.photosToDisplay[i] =  response.data.items[i]["link"];
              }
              $scope.selectTab($scope.views.photostabview);
        }
        else {
          $scope.showPhotosError = true;
          $scope.errortabmessage = "No Records";
          $scope.selectView($scope.views.itemdetailsview);
          $scope.selectTab("errorForTabs.html");
        }
    });
  }
  $scope.getShippingData = function(customIndex){
    $scope.resetErrorFlags();
    var idx = customIndex-1;
    if($scope.tempSearch != undefined && $scope.tempSearch[idx] != undefined && $scope.tempSearch[idx]["shippingInfo"] != undefined && $scope.tempSearch[idx]["shippingInfo"]["0"] != undefined)
    {
      if($scope.tempSearch[idx]["shippingInfo"]["0"]["shippingServiceCost"] != undefined && $scope.tempSearch[idx]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"] != undefined)
      {
          if ($scope.tempSearch[idx]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"] == "0.0")
            $scope.shippingInfo["Shipping Cost"] = "Free Shipping";
          else
          $scope.shippingInfo["Shipping Cost"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["shippingServiceCost"]["0"]["__value__"];
      }
      if($scope.tempSearch[idx]["shippingInfo"]["0"]["shipToLocations"] != undefined)
      {
          $scope.shippingInfo["Shipping Locations"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["shipToLocations"]["0"];
      }
      if($scope.tempSearch[idx]["shippingInfo"]["0"]["handlingTime"] != undefined)
      {
          if($scope.tempSearch[idx]["shippingInfo"]["0"]["handlingTime"]["0"] == "1")
          $scope.shippingInfo["Handling Time"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["handlingTime"]["0"] + " Day";
          else
          $scope.shippingInfo["Handling Time"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["handlingTime"]["0"] + " Days";
      }
      if($scope.tempSearch[idx]["shippingInfo"]["0"]["expeditedShipping"] != undefined)
      {
          $scope.shippingInfo["Expedited Shipping"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["expeditedShipping"]["0"];
      }
      if($scope.tempSearch[idx]["shippingInfo"]["0"]["oneDayShippingAvailable"] != undefined)
      {
          $scope.shippingInfo["One Day Shipping"] = $scope.tempSearch[idx]["shippingInfo"]["0"]["oneDayShippingAvailable"]["0"];
      }
      if($scope.tempSearch[idx]["returnsAccepted"] != undefined)
      {
          $scope.shippingInfo["Return Accepted"] = $scope.tempSearch[idx]["returnsAccepted"]["0"];
      }
      $scope.selectTab($scope.views.shippingtabview);
    }
    else{
      $scope.showShippingError = true;
      $scope.errortabmessage = "No Records."
      $scope.selectTab($scope.views.taberrorview);
    }
  };

 $scope.resetErrorFlags = function(){
    $scope.showProductError = false;
    $scope.showPhotosError = false;
    $scope.showShippingError = false;
    $scope.showSellerError = false;
    $scope.showSimilarError = false;
    $scope.errortabmessage = "";
  }//endof reset error flags

  $scope.getSellerDetails = function(){
    $scope.resetErrorFlags();
    if($scope.itemdetailsResults != undefined)
    {
      if($scope.itemdetailsResults["Seller"] != undefined)
      {
        if($scope.itemdetailsResults["Seller"]["UserID"] != undefined)
          $scope.sellerInfo["UserID"] = $scope.itemdetailsResults["Seller"]["UserID"];
        if($scope.itemdetailsResults["Seller"]["FeedbackScore"] != undefined)
        {
            $scope.sellerInfo["Feedback Score"] = $scope.itemdetailsResults["Seller"]["FeedbackScore"];
            if(parseInt($scope.sellerInfo["Feedback Score"]) >= 10000)
            $scope.sellerInfo["greater"] = true;
            else
            $scope.sellerInfo["greater"] = false;
        }
        if($scope.itemdetailsResults["Seller"]["PositiveFeedbackPercent"] != undefined)
          $scope.sellerInfo["Popularity"] = $scope.itemdetailsResults["Seller"]["PositiveFeedbackPercent"] ;
        if($scope.itemdetailsResults["Seller"]["FeedbackRatingStar"] != undefined)
        {
            var color = $scope.itemdetailsResults["Seller"]["FeedbackRatingStar"] ;
            switch (color) {
              case 'Yellow' :
              case 'YellowShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'yellow';
                break;
              case 'Blue' :
              case 'BlueShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'blue';
                break;
              case 'Turquoise':
              case 'TurquoiseShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'turquoise';
                break;
              case 'Purple':
              case 'PurpleShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'purple';
                break;
              case 'Red':
              case 'RedShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'red';
                break;
              case 'Green':
              case 'GreenShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'green';
                break;
              case 'Silver':
              case 'SilverShooting':
                $scope.sellerInfo["Feedback Rating Star"] = 'silver';
                break;
              default:
                $scope.sellerInfo["Feedback Rating Star"] = 'white';
                break;
            }
        }else{
                $scope.sellerInfo["Feedback Rating Star"] = 'white';
        }
        if($scope.itemdetailsResults["Seller"]["TopRatedSeller"] != undefined)
          $scope.sellerInfo["Top Rated"] = $scope.itemdetailsResults["Seller"]["TopRatedSeller"];
      }
      if($scope.itemdetailsResults["Storefront"] != undefined)
      {
        if($scope.itemdetailsResults["Storefront"]["StoreName"] != undefined)
          $scope.sellerInfo["Store Name"] = $scope.itemdetailsResults["Storefront"]["StoreName"];
        if($scope.itemdetailsResults["Storefront"]["StoreURL"] != undefined)
          $scope.sellerInfo["Buy Product At"] = $scope.itemdetailsResults["Storefront"]["StoreURL"];
      }
      $scope.selectTab($scope.views.sellertabview);
    }else{
      $scope.showSellerError = true;
      $scope.errortabmessage = "No Records."
      $scope.selectTab($scope.views.taberrorview);
    }
  }; //end of sellerInfo

  $scope.getSimilartItems = function(){
    $scope.resetErrorFlags();
    if($scope.itemdetailsResults == undefined){
      $scope.showSimilarError = true;
      $scope.errortabmessage = "No Records."
      $scope.selectTab($scope.views.taberrorview);
    }
    else
    {
      var itemId = $scope.itemdetailsResults["ItemID"];
      $http.get("http://haripriya-yeddula.us-east-2.elasticbeanstalk.com/similarItemsSearchroute?itemId="+itemId).then(function(response){
    //  $http.get("/similarItemsSearchroute?itemId="+itemId).then(function(response){

          if(response.data != undefined && response.data["getSimilarItemsResponse"] != undefined && response.data["getSimilarItemsResponse"]["itemRecommendations"] != undefined && response.data["getSimilarItemsResponse"]["itemRecommendations"]["item"] != undefined
          && response.data["getSimilarItemsResponse"]["itemRecommendations"]["item"]["0"] != undefined)
          {
                var similarItemsResponse = response.data["getSimilarItemsResponse"]["itemRecommendations"]["item"];
                $scope.similarItemsLength = similarItemsResponse.length;
                if(similarItemsResponse.length <= 5)
                    $scope.showMoreBtn = false;
                for(var i=0; i< similarItemsResponse.length ; i++){
                    $scope.similarItems[i] = {};
                  if(similarItemsResponse[i]["imageURL"] != undefined)
                    $scope.similarItems[i]["Image"] =  similarItemsResponse[i]["imageURL"];
                  if(similarItemsResponse[i]["title"] != undefined)
                    $scope.similarItems[i]["ProductName"] =  similarItemsResponse[i]["title"];
                  if(similarItemsResponse[i]["viewItemURL"] != undefined)
                    $scope.similarItems[i]["itemURL"] =  similarItemsResponse[i]["viewItemURL"]
                  if(similarItemsResponse[i]["buyItNowPrice"] != undefined && similarItemsResponse[i]["buyItNowPrice"]["__value__"] != undefined)
                    $scope.similarItems[i]["Price"] = parseInt(similarItemsResponse[i]["buyItNowPrice"]["__value__"]);
                  if(similarItemsResponse[i]["shippingCost"] != undefined && similarItemsResponse[i]["shippingCost"]["__value__"] != undefined)
                    $scope.similarItems[i]["ShippingCost"]  = parseInt(similarItemsResponse[i]["shippingCost"]["__value__"]);
                  if(similarItemsResponse[i]["timeLeft"] != undefined)
                  {
                    var tempval = similarItemsResponse[i]["timeLeft"];
                    var val = tempval.substring(tempval.indexOf("P") + 1, tempval.indexOf("D"));
                    $scope.similarItems[i]["DaysLeft"] = parseInt(val);
                  }
                  $scope.similarItemsArray.push($scope.similarItems[i]);
                }
                $scope.selectTab($scope.views.similarpdtstabview);
          }
          else{
            $scope.showSimilarError = true;
            $scope.errortabmessage = "No Records."
            $scope.selectTab($scope.views.taberrorview);
          }
      });
    }
 };//end of similaritems function

 $scope.ToggleShowMore = function(showMoreBtn){
    if(showMoreBtn == true)
    $scope.limit =  $scope.similarItemsLength;
    else
    $scope.limit = 5;
    $scope.showMoreBtn = !showMoreBtn;
 } //end of toggle showmore

 $scope.facebookShare = function(){
   var item_url = $scope.itemdetailsResults["ViewItemURLForNaturalSearch"];
   var title = $scope.parseditemdetails["Title"];
   var price = $scope.parseditemdetails["Price"];
   var msg = "Buy " + title + " at " + price + " from " + " below.";
   var facebook_url= "https://www.facebook.com/dialog/share?app_id=382094205958123&display=popup"+
   "&href="+item_url + "&quote=" + msg;
    window.open(facebook_url, '_blank');
 }; //end of fbshare

  $scope.toggleCartBtn = function(idx){
      if(idx != 1)
       var temp_idx = (idx-1)%10;
      if( idx == 1)
       var temp_idx = idx-1;
      if($scope.pagedItems!=[] && $scope.pagedItems[$scope.thisPage]!=undefined)
         var icn = $scope.pagedItems[$scope.thisPage][temp_idx]["in_cart"];
      else
      {
        for (var i = 0; i < $scope.wishtlistItems.length; i++)
          if($scope.wishtlistItems[i]["index"] == idx)
              var icn =   $scope.wishtlistItems[i]["in_cart"];
      }
     if(!icn){
       if($scope.pagedItems!=[] && $scope.pagedItems[$scope.thisPage]!=undefined);
         $scope.pagedItems[$scope.thisPage][temp_idx]["in_cart"] = !icn;
       if($scope.parseditemdetails != undefined)
         $scope.parseditemdetails["in_cart"] = !icn;
       $scope.addtoStorage($scope.pagedItems[$scope.thisPage][temp_idx], idx-1);
     }
     else{
       if($scope.pagedItems!=[] && $scope.pagedItems[$scope.thisPage]!=undefined)
       {  $scope.pagedItems[$scope.thisPage][temp_idx]["in_cart"] = !icn; }
       if($scope.parseditemdetails != undefined)
         $scope.parseditemdetails["in_cart"] = !icn;
       if($scope.wishtlistItems != undefined)
       {
           for (var i = 0; i < $scope.wishtlistItems.length; i++) {
             if($scope.wishtlistItems[i]["index"] == idx)
               { $scope.wishtlistItems[i]["in_cart"] = false;
                 $scope.wishtlistItems.splice(i,1); }
           }
       }
       $scope.removefromStorage(idx-1);
     }
   }; //endoftogglecartbtn

 $scope.pageGrouping = function() {
       $scope.pagedItems = [];
       for (var i = 0; i < $scope.totalItems; i++) {
           if (i % $scope.perPageResults === 0)
               $scope.pagedItems[Math.floor(i/$scope.perPageResults)] = [$scope.resultTableData.items[i]];
           else
               $scope.pagedItems[Math.floor(i/$scope.perPageResults)].push($scope.resultTableData.items[i]);
       } };//end of page grouping

 $scope.addtoStorage = function(item, index){
   localStorage.setItem(index, JSON.stringify(item));
  }

 $scope.removefromStorage = function(idx){
   localStorage.removeItem(idx);
   if($scope.selectedView == $scope.views.wishlisttabview)
      $scope.fetchWishlist();
 }    //endof removefromStorage()

 $scope.fetchWishlist = function(){
            $scope.wishtlistItems = [];
            $scope.wishlist_total = 0;
            if(localStorage.length == 0){
              $scope.selectView($scope.views.progressanderrorsview);
              $scope.showError = true;
              $scope.errormessage = "No Records";
              $scope.showDetailsbtnwl = false;
            }
            else
            {
              $scope.showError = false; var len=0;
              for (var key in localStorage) {
                if(!isNaN(key))
                 {  $scope.wishtlistItems.push(JSON.parse(localStorage.getItem(key))); len++;}
              }
              for(var i=0; i< len; i++) {
                 $scope.wishlist_total = $scope.wishlist_total + parseFloat($scope.wishtlistItems[i]["price"].substr(1));
               }
              $scope.wishlist_total = "$" + $scope.wishlist_total.toFixed(2);
              $scope.resetHighlightForWishlist();
              $scope.selectView($scope.views.wishlisttabview);
            }
 }; //end of fetchWishlist()

 $scope.setPageToi = function() { $scope.thisPage = this.i;};

 $scope.resetHighlightForWishlist = function(){
    if( $scope.wishtlistItems != undefined && $scope.wishtlistItems != []){
      for(var variable in $scope.wishtlistItems){
          $scope.wishtlistItems[variable]["highlight"] = false;
        }
    }
 }; //end of wishlist reset highlight

}); //end of container
